const prod1= "batata"
const prod2= "pizza"
const prod3= "arroz e feijão"
const prod4= "macarrão"
const prod5= "pitaya"
const prod6= "haburguer"

const  produtos= ["batata", "pizza", "arroz e feijão", "macarrão", "pitaya" , "haburguer"]
//                   0          1           2              3           4           5

console.log(produtos[0])
console.log(produtos[1])
console.log(produtos[2])
console.log(produtos[3])
console.log(produtos[4])
console.log(produtos[5])

