const nome = "Batata"
function retornaDados(){
  
  return nome.toUpperCase()
}
const dados = retornaDados()
console.log(dados)

/**
 * crie uma função que receba (nome, idade, cpf)
 * retorne os dados formatados com uma mensagem com todos os dado
 * armazene em uma variável e imprima com console.log()
 */

