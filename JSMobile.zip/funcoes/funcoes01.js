/**
*funções: São blocos de códico que podem ser reproveitados*
  * funçoes podem ou não ter nomes
* podem ou não ter parametros
*/
// Criar ou declarar funções
function dizOla() {
  //código
  console.log('Olá! OWO')
}
// involcar/ chamar função
//dizOla('Zedin')
//dizOla('Batata')
//dizOla('Deniel')

//adição
function somaDeNomes(x, y) {
  console.log(x + y)
}
somaDeNomes(15, 8)
somaDeNomes(3, 90)

//Subitração
function subitracaoDeNomes(x, y) {
  console.log(x - y)

}

subitracaoDeNomes(8976, 456)
subitracaoDeNomes(8954, 34097)

//Multiplicação
function multiplicaçãoDeNomes(x, y) {
  console.log(x * y)
}

multiplicaçãoDeNomes(4, 5)
multiplicaçãoDeNomes(42, 89)

//Divisão
function divisãoDeNomes(x, y) {
  console.log(x / y)
}

divisãoDeNomes(20, 2)
divisãoDeNomes(100, 75)