//function soma(n1, n2) {
//  if(typeof n1 === 'number' && typeof n2 === 'number'){
//const res = n1 + n2;
//alert ( 'O resultado foi ' + res)
//}else{
//alert('Desculpa ocorreu um erro. o.o')
//}
//}
//soma(84, 64)
//soma("JULEICA", 36)
//soma('1', 69)
//soma(-20, 934)

//Crie uma função que receba como parâmetos:
//nome, altura
//chaque se nome é do tipo "string"
//chaque se altura é do tipo "number"
//se ambas forem vedadeiras retorne uma mensagem.


//function mensagem(nome, altura) {

//if (typeof nome === 'string') {
//if (typeof altura === 'number') {
//const mensagem = "Olá, " + nome + " você tem " + altura + " de altura."
//alert(mensagem)
//}
//}
//else {
//alert('Desculpa, ocorreu um erro. o.o')
//}
//}

//mensagem("kraven",0.63)
//mensagem(88,0.63)

//function dadosDoUsuario(nome, sobrenome){
// if ( typeof nome === 'string')
//  if ( typeof sobrenome === 'string'){
//    const mensagem = "Olá, " + nome + " " + sobrenome + "! ≧◠‿●‿◠≦"
//    alert(mensagem)
// }
//else {
// alert('sinto muito, tente novamente.(ㆆ_ㆆ)')
// }
//}
//dadosDoUsuario("Carlos", "Santos")

//function nomeeAltura(nome, altura){
// if (typeof nome === 'string')
// if (typeof altura === 'number'){
//    const mensagem = "Olá, " + nome + " você tem " + altura + " de altura."
//     alert(mensagem)
//  }
//else{
//  alert('Você cometeu um erro. por favor, tente novamente. -_-')
// }
//}
//nomeeAltura("Juleica", 1.63)



// Crie uma função que:
/**
 * Receba um número com parâmetro e cheque se (if):
 * n% 2 === 0  então imprima "O número" + n + "é par"
 * Se não (else), imprima "O número" + n + "é ímpar!"
 */

//function numeros(n) {

//if (typeof n === 'number') {

// if (n % 2 === 0) {
//   alert("O número " + n + " é par. (＾▽＾)")
//}
// else {
//  alert("O número " + n + " é ímpar. (＾-＾)")
//}
// }else {
//  alert("Desculpa, ocorreu um erro. (:|)")
//}


//}

//numeros(96744)
//numeros("batata")
//numeros(0.5)
